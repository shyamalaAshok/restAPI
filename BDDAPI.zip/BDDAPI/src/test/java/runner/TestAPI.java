package runner;
import io.cucumber.core.logging.Logger;
import io.cucumber.core.logging.LoggerFactory;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
		features = {"Feature/RestAPIGet.feature"}
		,glue={"stepDefinition"}
		,monochrome = true
		,plugin = { "json:build/cucumber-reports/cucumber.json",
					"rerun:build/cucumber-reports/rerun.txt",
					"html:build/cucumber-reports/report.html"
		           }		
		)

public class TestAPI extends AbstractTestNGCucumberTests{
	private static final Logger log = LoggerFactory.getLogger(TestAPI.class);

}
