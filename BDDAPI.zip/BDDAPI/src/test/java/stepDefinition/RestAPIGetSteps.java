package stepDefinition;

import java.util.logging.Logger;
import org.testng.Assert;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class RestAPIGetSteps {

	private Response response; 
	private static Logger log;
	
	@Given("^I do a GET call to (.+)$")
	public void i_do_a_get_call_to(String url) throws Throwable {

		System.out.println("Get the response from the URL: "+url);
		RequestSpecification requestSepcification = RestAssured.given(); 
		response =requestSepcification.when().get(url); 
	}


	@Then("^response is (.+)$") 
	public void response_is(String statusCode) throws Throwable { 

		int actualResponseCode = response.then().extract().statusCode();
		System.out.println("Got the status code: "+ actualResponseCode);
		Assert.assertEquals(statusCode,actualResponseCode +""); } }
