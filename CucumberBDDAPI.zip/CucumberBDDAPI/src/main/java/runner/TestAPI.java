package runner;

import io.cucumber.core.logging.Logger;
import io.cucumber.core.logging.LoggerFactory;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"src/test/resources/featureFiles/RestAPIGet.feature"},
        glue = {"src/test/java/stepDefinitions"},
        monochrome = true,
        plugin = {
                "json:build/cucumber-reports/cucumber.json",
                "rerun:build/cucumber-reports/rerun.txt"})

public class TestAPI{
    private static final Logger log = LoggerFactory.getLogger(TestAPI.class);

    //log.info("Logs");

}

