package stepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;

import java.util.logging.Logger;

public class RestAPIGetSteps {
    private Response response;
    private static Logger log;
    @Given("I do a GET call to {string}")
    public void iDoAGETCallTo(String url)throws Throwable {
        RequestSpecification requestSepcification = RestAssured.given();
        response = requestSepcification.when().get(url);
        throw new io.cucumber.java.PendingException();
    }

    @Then("response is {string}")
    public void responseIs(String statusCode)throws Throwable{
        int actualResponseCode = response.then().extract().statusCode();
        Assert.assertEquals(statusCode,  actualResponseCode +"");
        throw new io.cucumber.java.PendingException();
    }
}
